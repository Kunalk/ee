# Getting Started
version number 37981f84a50f54cb59378870e3f06ea1c17db7d7

### In order to generate this jar, you should run:

    mvn package

It will clean, compile and generate a jar at target dir , shopping-cart-0.0.1-SNAPSHOT

### In order to run  junit test case,

	mvn -Dtest=ShoppingCartServiceTest test -- 7 test cases

