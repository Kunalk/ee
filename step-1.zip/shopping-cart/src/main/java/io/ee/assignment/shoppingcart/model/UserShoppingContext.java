package io.ee.assignment.shoppingcart.model;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

/**
    This is user's shopping context which is associated with session.
    This class maintains the user selected products and corresponding quantity.
    This class also calculates the total cart price based on user selection of products.
 */
public class UserShoppingContext {

    Map<ShoppingProduct, Long > userShoppingRepository = new HashMap<>();
    private BigDecimal totalPrice = BigDecimal.ZERO;
    private Long totalQuantity = 0L;
    /**
     * Method to add a shopping product into the repository.
     * @param shoppingProduct the product which is selected by user
     * @param quantity total quantity selected by user
     */
    public void addShoppingProduct(ShoppingProduct shoppingProduct, Long quantity){
        if(userShoppingRepository.containsKey(shoppingProduct)){
            userShoppingRepository.put(shoppingProduct, userShoppingRepository.get(shoppingProduct)+quantity);
        }else{
            userShoppingRepository.put(shoppingProduct, quantity);
        }
        totalPrice = totalPrice.add(shoppingProduct.getPrice().multiply(new BigDecimal(quantity)));
        totalQuantity += quantity;
    }

    /**
     * Method to get the shopping repository selected by the user.
     * @return Map<ShoppingProduct, Long > Map of product and the quantity
     */
    public Map<ShoppingProduct, Long > getUserShoppingRepository(){
        return this.userShoppingRepository;
    }

    /**
     * Method to get the current user selected products total price
     * @return BigDecimal total cart price
     */
    public BigDecimal getTotalCartPrice(){
        return this.totalPrice;
    }

    /**
     * Method to get the total selected quantity by the user for all products
     * @return Long total quantity
     */
    public Long getTotalQuantity(){
        return this.totalQuantity;
    }

    /**
     * Method to get total selected individual product based quantity in cart
     * @param shoppingProduct product
     * @return total quantity
     */
    public Long getTotalQuantityForProduct(ShoppingProduct shoppingProduct){
        if(userShoppingRepository.containsKey(shoppingProduct)){
            return userShoppingRepository.get(shoppingProduct);
        }else{
            return 0L;
        }
    }
}
