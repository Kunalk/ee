package io.ee.assignment.shoppingcart.model;

import java.io.Serializable;
import java.math.BigDecimal;

/** Interface which all shopping products should implement to provide default implementation
 */
public interface IProduct extends Serializable{

    /**
     * Get the name of the product which is considered as Unique Key
     * @return
     */
    String getName();

    /**
     * Get the individual price of product
     * The default implementation provides ZERO Value
     * @return
     */
    default BigDecimal getPrice(){
        return BigDecimal.ZERO;
    }

}
