package io.ee.assignment.shoppingcart.service;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import io.ee.assignment.shoppingcart.model.ShoppingProduct;
import io.ee.assignment.shoppingcart.model.UserShoppingContext;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.math.BigDecimal;
import java.util.concurrent.TimeUnit;

/**
 * Cache based implementation of shopping cart service
 */
@Service
public class ShoppingCartServiceImpl implements ShoppingCartService {

    /**
     * Used Cache to store the user shopping cart activities, as a replacement to DB.
     */
    private Cache<Long, UserShoppingContext> cachedData ;

    /**
     * Initialize the cache
     */
    @PostConstruct public void init(){
        cachedData = CacheBuilder.newBuilder().expireAfterWrite(
                10, TimeUnit.MINUTES).build();//currently configure 10 min, but can be configured in external properties
    }

    @Override
    public void addToCart(Long userId, ShoppingProduct shoppingProduct, Long quantity) {

        // verify the input values
        if(quantity<=0){
            throw new RuntimeException("Product quantity cannot be 0 or negative");
        }

        if(userId ==null){
            throw new RuntimeException("User cannot be NULL");
        }

        if(shoppingProduct == null){
            throw new RuntimeException("Product cannot be NULL");
        }

        // store the product into repository
        UserShoppingContext userShoppingContext = cachedData.getIfPresent(userId);
        if(userShoppingContext ==null){
            userShoppingContext = new UserShoppingContext();
        }
        userShoppingContext.addShoppingProduct(shoppingProduct, quantity);
        cachedData.put(userId, userShoppingContext);
    }

    @Override
    public BigDecimal getTotalPrice(Long userId) {
        UserShoppingContext userShoppingContext = cachedData.getIfPresent(userId);
        if(userShoppingContext !=null){
            return (userShoppingContext.getTotalCartPrice()).setScale(2, BigDecimal.ROUND_HALF_UP);
        }
        return BigDecimal.ZERO.setScale(2, BigDecimal.ROUND_HALF_UP);
    }

    @Override
    public void clearCart(Long userId) {
        cachedData.invalidate(userId);
    }

    @Override
    public Long getTotalSelectedQuantity(Long userId) {
        UserShoppingContext userShoppingContext = cachedData.getIfPresent(userId);
        if(userShoppingContext !=null){
            return userShoppingContext.getTotalQuantity();
        }
        return 0L;
    }

    @Override
    public Long getTotalSelectedProductQuqntity(Long userId, ShoppingProduct shoppingProduct) {
        UserShoppingContext userShoppingContext = cachedData.getIfPresent(userId);
        if(userShoppingContext !=null){
            return userShoppingContext.getTotalQuantityForProduct(shoppingProduct);
        }
        return 0L;
    }
}
