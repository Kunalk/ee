package io.ee.assignment.shoppingcart.service;

import java.math.BigDecimal;

/**
 * Interface to expose the Sales Tax calculation related methods
 */
public interface ShoppingSalesTaxService {

    /**
     * Method to calculate the overall sales tax with standard rate for all items.
     * It throws RuntimeException if cart amount is NULL or negative
     * @param totalCartAmount total price of the selected user products
     * @return sales tax on total cart products
     */
    BigDecimal getTotalSalesTaxForCart(BigDecimal totalCartAmount);

    /**
     * Method to set the standard tax rate to be applied across all products
     * @param taxRate BigDecimal standard tax rate
     */
    void setSalesTaxRate(BigDecimal taxRate);

    /**
     * Method to get the configured standard tax rate
     * @return taxRate BigDecimal standard tax rate
     */
    BigDecimal getTotalSalesTaxRate();

}
