package io.ee.assignment.shoppingcart.model;

import java.math.BigDecimal;
import java.util.HashMap;

/** This is Shopping Product class which implements IProduct Interface.
 *  This class considers Name of the product as Key which is unique across products
 */
public final class ShoppingProduct implements IProduct {

    private String productName;
    private BigDecimal productUnitPrice;

    public ShoppingProduct(String productName, BigDecimal productUnitPrice) {
        this.productName = productName;
        this.productUnitPrice = productUnitPrice;
    }

    @Override
    public BigDecimal getPrice() {
        return this.productUnitPrice;
    }

    @Override
    public String getName() {
        return this.productName;
    }

    /**
     * Indicates whether some other object is "equal to" this one.
     * <p>
     *
     *
     * @param obj the reference object with which to compare.
     * @return {@code true} if this object is the same as the obj
     * argument; {@code false} otherwise.
     * @see #hashCode()
     * @see HashMap
     */
    @Override
    public boolean equals(Object obj) {
        if(obj instanceof ShoppingProduct){
            return this.getName().equals(((ShoppingProduct) obj).getName());
        }
        return false;
    }
}
