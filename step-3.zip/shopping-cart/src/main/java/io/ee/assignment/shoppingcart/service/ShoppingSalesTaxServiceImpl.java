package io.ee.assignment.shoppingcart.service;

import org.springframework.stereotype.Service;

import java.math.BigDecimal;

/**
 * Implementation of ShoppingSalesTaxService
 */
@Service
public class ShoppingSalesTaxServiceImpl implements  ShoppingSalesTaxService {

    private static BigDecimal STANDARD_SALES_TAX = new BigDecimal(0.125);
    /**
     * Method to calculate the overall sales tax with standard rate for all items
     *
     * @param totalCartAmount total price of the selected user products
     * @return sales tax on total cart products
     */
    @Override
    public BigDecimal getTotalSalesTaxForCart(BigDecimal totalCartAmount) {
        if(totalCartAmount == null || totalCartAmount.compareTo(BigDecimal.ZERO) < 0){
            throw new RuntimeException("Cart amount should be positive value and non null");
        }
        return totalCartAmount.multiply(STANDARD_SALES_TAX).setScale(2, BigDecimal.ROUND_HALF_UP);
    }

    /**
     * Method to set the standard tax rate to be aplied across all products
     *
     * @param taxRate BigDecimal standard tax rate
     */
    @Override
    public void setSalesTaxRate(BigDecimal taxRate) {
        if(taxRate != null && taxRate.compareTo(BigDecimal.ZERO) > 0){
            this.STANDARD_SALES_TAX = taxRate;
        }
    }

    /**
     * Method to get the configured standard tax rate
     *
     * @return taxRate BigDecimal standard tax rate
     */
    @Override
    public BigDecimal getTotalSalesTaxRate() {
        return this.STANDARD_SALES_TAX;
    }
}
