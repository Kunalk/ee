package io.ee.assignment.shoppingcart.service;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.math.BigDecimal;

@SpringBootTest
@RunWith(SpringRunner.class)
public class ShoppingSalesTaxServiceTest {

    @Autowired
    private ShoppingSalesTaxService shoppingSalesTaxService;

    @Before
    public void before(){
        shoppingSalesTaxService.setSalesTaxRate(new BigDecimal(0.125));
    }

    /**
     * Test for setting valid sales tax rate and verifying it
     */
    @Test
    public void testSetSalesTaxWithValidValues(){
        shoppingSalesTaxService.setSalesTaxRate(new BigDecimal(0.1));
        Assert.assertEquals(new BigDecimal(0.1), shoppingSalesTaxService.getTotalSalesTaxRate());
    }

    /**
     * Test for setting NULL sales tax, which would not set the value and previous value should be returned
     */
    @Test
    public void testNullSalesTaxSet(){
        shoppingSalesTaxService.setSalesTaxRate(null);
        Assert.assertEquals(new BigDecimal(0.125), shoppingSalesTaxService.getTotalSalesTaxRate());
    }

    /**
     * Test for setting negative sales tax, which would not set the value and previous value should be returned
     */
    @Test
    public void testNegaiveSalesTaxSet(){
        shoppingSalesTaxService.setSalesTaxRate(new BigDecimal(-1));
        Assert.assertEquals(new BigDecimal(0.125), shoppingSalesTaxService.getTotalSalesTaxRate());
    }
}
