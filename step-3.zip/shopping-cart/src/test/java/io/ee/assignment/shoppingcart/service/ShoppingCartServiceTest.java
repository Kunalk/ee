package io.ee.assignment.shoppingcart.service;

import io.ee.assignment.shoppingcart.model.ShoppingProduct;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.math.BigDecimal;

/**
 */
@SpringBootTest
@RunWith(SpringRunner.class)
public class ShoppingCartServiceTest {

    @Autowired
    ShoppingCartService shoppingCartService;

    @Autowired
    private ShoppingSalesTaxService shoppingSalesTaxService;


    @Before
    public void before(){
        shoppingCartService.clearCart(1L);
        shoppingSalesTaxService.setSalesTaxRate(new BigDecimal(0.125));
    }

    /**
     * Test for empty records at initial stage
     */
    @Test
    public void testShoppingCartInitiallyEmptyForUser(){
        Assert.assertEquals(shoppingCartService.getTotalPrice(1L), BigDecimal.ZERO.setScale(2, BigDecimal.ROUND_HALF_UP));
        Assert.assertTrue(shoppingCartService.getTotalSelectedQuantity(1L)== 0L);

        ShoppingProduct shoppingProduct = new ShoppingProduct("Dove Soap",new BigDecimal(39.99));
        Assert.assertTrue(shoppingCartService.getTotalSelectedProductQuqntity(1L, shoppingProduct)== 0L);
    }



    /**
     * Test case to verify shopping of 2 different products and total quantity and price of cart.
     */
    @Test
    public void testAddMultipleValidDifferentProductsToCart(){

        ShoppingProduct shoppingProduct = new ShoppingProduct("Dove Soap",new BigDecimal(39.99));
        shoppingCartService.addToCart(1L, shoppingProduct, 5L);
        BigDecimal totalCartPrice = shoppingCartService.getTotalPrice(1L);
        Assert.assertEquals( totalCartPrice, new BigDecimal(224.94).setScale(2, BigDecimal.ROUND_HALF_UP));

        Assert.assertTrue(shoppingCartService.getTotalSelectedQuantity(1L)== 5L);

        Assert.assertTrue(shoppingCartService.getTotalSelectedProductQuqntity(1L, shoppingProduct)== 5L);

        //--------------------------------------------------------------------

        ShoppingProduct shoppingProduct2 = new ShoppingProduct("Axe Deo",new BigDecimal(99.99));
        shoppingCartService.addToCart(1L, shoppingProduct2, 3L);
        totalCartPrice = shoppingCartService.getTotalPrice(1L);
        Assert.assertEquals( totalCartPrice, new BigDecimal(562.41).setScale(2, BigDecimal.ROUND_HALF_UP));

        Assert.assertTrue(shoppingCartService.getTotalSelectedQuantity(1L)== 8L);

        Assert.assertTrue(shoppingCartService.getTotalSelectedProductQuqntity(1L, shoppingProduct2)== 3L);
        Assert.assertTrue(shoppingCartService.getTotalSelectedProductQuqntity(1L, shoppingProduct)== 5L);
    }



    /**
     * Test for adding product into the cart with valid values and verifying the total quantity and price
     */
    @Test
    public void testAddMultipleValidProductsToCart(){

        ShoppingProduct shoppingProduct = new ShoppingProduct("Dove Soap",new BigDecimal(39.99));
        shoppingCartService.addToCart(1L, shoppingProduct, 5L);
        BigDecimal totalCartPrice = shoppingCartService.getTotalPrice(1L);
        Assert.assertEquals( totalCartPrice, new BigDecimal(224.94).setScale(2, BigDecimal.ROUND_HALF_UP));

        Assert.assertTrue(shoppingCartService.getTotalSelectedQuantity(1L)== 5L);

        Assert.assertTrue(shoppingCartService.getTotalSelectedProductQuqntity(1L, shoppingProduct)== 5L);

        //--------------------------------------------------------------------

        shoppingCartService.addToCart(1L, shoppingProduct, 3L);
        totalCartPrice = shoppingCartService.getTotalPrice(1L);
        Assert.assertEquals( totalCartPrice, new BigDecimal(359.91).setScale(2, BigDecimal.ROUND_HALF_UP));

        Assert.assertTrue(shoppingCartService.getTotalSelectedQuantity(1L)== 8L);

        Assert.assertTrue(shoppingCartService.getTotalSelectedProductQuqntity(1L, shoppingProduct)== 8L);

    }

    /**
     * Test case to verify shopping of 2 different products and total quantity and price of cart.
     */
    @Test
    public void testAddMultipleValid2DifferentProductsToCart(){

        ShoppingProduct shoppingProduct = new ShoppingProduct("Dove Soap",new BigDecimal(39.99));
        shoppingCartService.addToCart(1L, shoppingProduct, 5L);
        BigDecimal totalCartPrice = shoppingCartService.getTotalPrice(1L);
        Assert.assertEquals( totalCartPrice, new BigDecimal(224.94).setScale(2, BigDecimal.ROUND_HALF_UP));

        Assert.assertTrue(shoppingCartService.getTotalSelectedQuantity(1L)== 5L);

        Assert.assertTrue(shoppingCartService.getTotalSelectedProductQuqntity(1L, shoppingProduct)== 5L);

        //--------------------------------------------------------------------

        ShoppingProduct shoppingProduct2 = new ShoppingProduct("Dove Shampoo",new BigDecimal(39.99));
        shoppingCartService.addToCart(1L, shoppingProduct2, 3L);
        totalCartPrice = shoppingCartService.getTotalPrice(1L);
        Assert.assertEquals( totalCartPrice, new BigDecimal(359.91).setScale(2, BigDecimal.ROUND_HALF_UP));

        Assert.assertTrue(shoppingCartService.getTotalSelectedQuantity(1L)== 8L);

        Assert.assertTrue(shoppingCartService.getTotalSelectedProductQuqntity(1L, shoppingProduct2)== 3L);
        Assert.assertTrue(shoppingCartService.getTotalSelectedProductQuqntity(1L, shoppingProduct)== 5L);
    }



    /**
     * Test for adding product into the cart with valid values and verifying the total quantity and price
     */
    @Test
    public void testAddProductsToCart(){

        ShoppingProduct shoppingProduct = new ShoppingProduct("Dove Soap",new BigDecimal(39.99));
        shoppingCartService.addToCart(1L, shoppingProduct, 5L);
        BigDecimal totalCartPrice = shoppingCartService.getTotalPrice(1L);
        Assert.assertEquals( totalCartPrice, new BigDecimal(224.94).setScale(2, BigDecimal.ROUND_HALF_UP));

        Assert.assertTrue(shoppingCartService.getTotalSelectedQuantity(1L)== 5L);

        Assert.assertTrue(shoppingCartService.getTotalSelectedProductQuqntity(1L, shoppingProduct)== 5L);
    }

    /**
     * Test for adding product with 0 quantity, which throws exception
     */
    @Test(expected = RuntimeException.class)
    public void testAddProductsToCartWithZeroQuantity(){
        ShoppingProduct shoppingProduct = new ShoppingProduct("Dove Soap",new BigDecimal(39.99));
        shoppingCartService.addToCart(1L, shoppingProduct, 0L);
    }

    /**
     * Test for adding product with negative quantity, which throws exception
     */
    @Test(expected = RuntimeException.class)
    public void testAddProductsToCartWithNegativeQuantity(){
        ShoppingProduct shoppingProduct = new ShoppingProduct("Dove Soap",new BigDecimal(39.99));
        shoppingCartService.addToCart(1L, shoppingProduct, -1L);
    }

    /**
     * Test for adding product with null user, which throws exception
     */
    @Test(expected = RuntimeException.class)
    public void testAddProductsToCartWithNULLUserid(){
        ShoppingProduct shoppingProduct = new ShoppingProduct("Dove Soap",new BigDecimal(39.99));
        shoppingCartService.addToCart(null, shoppingProduct, 1L);
    }

    /**
     * Test for adding null product , which throws exception
     */
    @Test(expected = RuntimeException.class)
    public void testAddProductsToCartWithNullProduct(){
        shoppingCartService.addToCart(1L, null, 1L);
    }
}
