package io.ee.assignment.shoppingcart.service;

import io.ee.assignment.shoppingcart.model.ShoppingProduct;

import java.math.BigDecimal;

/**
 * Interface to expose the basic shopping cart service
 */
public interface ShoppingCartService {

    /**
     * Method to add the product for a user into the cart.
     * <p>
     *     This method throws RuntimeException if params are not valid
     * @param userId user id of the current logged session
     * @param shoppingProduct shopping product
     * @param quantity total quantity selected
     */
    void addToCart(Long userId, ShoppingProduct shoppingProduct, Long quantity) throws RuntimeException;

    /**
     * Method to get the total price of the products user has selected based on the individual product price
     * @param userId user id of the current logged session
     * @return total price, if no product selected then 0.00
     */
    BigDecimal getTotalPrice(Long userId);

    /**
     * Method to clear the cart for a user.
     * @param userId user id of the current logged session
     */
    void clearCart(Long userId);

    /**
     * Method to get total selected quantity across all products by user.
     * @param userId user id of the current logged session
     * @return if user has selected valid values then the count; otherwise 0
     */
    Long getTotalSelectedQuantity(Long userId);

    /**
     * Method to get the total selected quantity for a product by a user.
     * @param userId user id of the current logged session
     * @param shoppingProduct shopping product
     * @return if user has selected valid values then the count; otherwise 0
     */
    Long getTotalSelectedProductQuqntity(Long userId, ShoppingProduct shoppingProduct);
}
